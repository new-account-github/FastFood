package com.poly.controller.user;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.poly.dao.ProductDAO;
import com.poly.entity.Product;
import com.poly.service.SessionService;

@Controller
public class ShopController {
	@Autowired
	ProductDAO productDAO;
	
	@Autowired
	SessionService sessionService;
	
	@RequestMapping("/shop")
	public String shop(Model model) {
		List<Product> items = productDAO.findAll();
		model.addAttribute("items", items);
		return "home/shop";
	}
	
	@PostMapping("/shop/findByName")
	public String findByName(Model model, @RequestParam("keyword") Optional<String> kw) {
		String kwords = kw.orElse(sessionService.get("keywords", ""));
		sessionService.set("keywords", kwords);
		List<Product> items = productDAO.findByKeyWord("%" + kwords + "%" );
		model.addAttribute("items", items);
		return "home/shop";
	}
}
