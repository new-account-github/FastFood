package com.poly.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.poly.dao.AccountDAO;
import com.poly.entity.Account;

@Controller
public class RegisterController {
	@Autowired
	AccountDAO dao;
	/*
	 * @Autowired MailerService mailer;
	 */
	

	@RequestMapping("/home/register")
	public String register() {
		return "/home/register";
	}

	@PostMapping("/home/register")
	public String viewsregister(@Validated Account acc, BindingResult result) {
		if (result.hasErrors()) {
			return "/home/register";
		} else {
			acc.setAdmin(false);
			acc.setActive(true);
			dao.save(acc);
//			if (!dao.existsById(acc.getUsername())) {
			dao.save(acc);
				return "redirect:/home/index";
//			}
//			throw new RuntimeException("Username is exist, please enter new username");
		}
		}

//	}

}
