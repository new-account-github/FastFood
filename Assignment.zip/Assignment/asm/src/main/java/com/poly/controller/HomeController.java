package com.poly.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.poly.dao.ProductDAO;
import com.poly.entity.CartItem;
import com.poly.entity.Product;


@Controller
public class HomeController {
	@Autowired
	ProductDAO productDAO;
	
	
	
	List<CartItem> cartItems = new ArrayList<>();
	
	@RequestMapping("/home/index")
	public String index( ) {
		return "home/index";
	}

	@RequestMapping("/cart")
	public String cart(Model model) {
		model.addAttribute("cartItems", cartItems);
		return "home/cart";
	}
	
	@PostMapping("/add/cart")
	public String addtoCart(@RequestParam("id") int id,@RequestParam("quantity") int quantity) {
		Product product = productDAO.getReferenceById(id);
		
		CartItem cartItem = new CartItem();
		cartItem.setProduct(product);
		cartItem.setQuantity(quantity);
		cartItems.add(cartItem);
		
		return "redirect:/cart";
	}
	
	
	@RequestMapping("/detail")
	public String detail() {
		return "home/detail";
	}


	@RequestMapping("/order")
	public String order() {
		return "home/order";
	}

}
