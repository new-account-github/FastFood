package com.poly.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.poly.dao.AccountDAO;
import com.poly.entity.Account;

@Controller
public class AccountController {
	@Autowired
	AccountDAO accountDAO;
	
	@RequestMapping("/admin/account")
	public String admin(Model model) {
		Account account = new Account();
		model.addAttribute("us", account);
		List<Account> list = accountDAO.findAll();
		model.addAttribute("accounts", list);
		return "/admin/account";
	}
	
	@RequestMapping("/admin/account/create")
	public String createAccount(Account account) {
		accountDAO.save(account);
		return "redirect:/admin/account";
	}
	
	@RequestMapping("/admin/account/edit/{id}")
	public String editAccount(Model model, @PathVariable("id") Long id) {
		Account account = accountDAO.getReferenceById(id);
		model.addAttribute("us", account);
		List<Account> list = accountDAO.findAll();
		model.addAttribute("accounts", list);
		return "/admin/account";
	}
	
	@RequestMapping("/admin/account/update")
	public String updateAccount(Account account) {
		accountDAO.save(account);
		return "redirect:/admin/account/edit/" + account.getId();
	}
	
	
}
