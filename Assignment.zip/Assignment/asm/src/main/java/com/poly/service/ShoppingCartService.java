package com.poly.service;

import java.util.Map;

import com.poly.entity.Product;

public interface ShoppingCartService {
	
	void add(int id);
	
	void remove(int id);
	
	void update(int id, int quantity);
	
	Map<Integer,Product> getItems();
	
	void clear();
	
	int getCount();
	
	Double getAmount();
}
